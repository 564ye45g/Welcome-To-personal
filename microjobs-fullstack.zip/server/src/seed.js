import { getDb, run } from './lib/db.js';

const categories = [
  'Survey','Sign-up','App Install','Social Follow','Comment','Like/React','Share','Watch Video',
  'Click Ads','Data Entry','Write Review','Screenshot','Test Website','Bug Hunt','Download',
  'Forum Post','Join Group','Invite Friend','Rate App','Email Subscribe'
];

async function main(){
  const db = getDb();
  for (let i=1;i<=100;i++){
    const cat = categories[i % categories.length];
    const price = 1 + (i % 7);
    await run(db, `INSERT INTO tasks(title,category,description,external_url,price_cents,slots_total,created_by)
      VALUES (?,?,?,?,?,?,?)`, [
        `Sample Task #${i}`,
        cat,
        `Do the ${cat} action as instructed and submit proof.`,
        '',
        price,
        20,
        1
      ]);
  }
  db.close();
  console.log('Seeded 100 tasks.');
}
main();
