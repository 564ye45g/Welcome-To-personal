import { Router } from 'express';
import { getDb, get, all, run } from '../lib/db.js';
import { authRequired, adminOnly } from '../middleware/auth.js';

const router = Router();

router.get('/stats', authRequired, adminOnly, async (req, res) => {
  const db = getDb();
  const users = await get(db, 'SELECT COUNT(*) as c FROM users', []);
  const tasks = await get(db, 'SELECT COUNT(*) as c FROM tasks', []);
  const pending = await get(db, "SELECT COUNT(*) as c FROM submissions WHERE status='pending'", []);
  db.close();
  res.json({ users: users.c, tasks: tasks.c, pending: pending.c });
});

router.get('/submissions', authRequired, adminOnly, async (req, res) => {
  const db = getDb();
  const rows = await all(db, `SELECT s.*, t.title as task_title, u.name as user_name 
    FROM submissions s 
    JOIN tasks t ON t.id=s.task_id 
    JOIN users u ON u.id=s.user_id 
    WHERE s.status='pending' ORDER BY s.id ASC LIMIT 200`, []);
  db.close();
  res.json(rows);
});

router.post('/submissions/:id/decision', authRequired, adminOnly, async (req, res) => {
  const { decision } = req.body || {};
  const db = getDb();
  const s = await get(db, 'SELECT * FROM submissions WHERE id=?', [req.params.id]);
  if (!s || s.status !== 'pending') { db.close(); return res.status(400).json({ error: 'Invalid submission' }); }
  const task = await get(db, 'SELECT * FROM tasks WHERE id=?', [s.task_id]);
  if (!task) { db.close(); return res.status(400).json({ error: 'Task not found' }); }
  if (decision === 'approve') {
    await run(db, "UPDATE submissions SET status='approved', reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?", [req.user.id, s.id]);
    await run(db, 'UPDATE users SET balance_cents=balance_cents+? WHERE id=?', [task.price_cents, s.user_id]);
    await run(db, 'INSERT INTO txns(user_id, amount_cents, type, meta) VALUES (?,?,?,?)',
      [s.user_id, task.price_cents, 'earn', JSON.stringify({ task_id: s.task_id, submission_id: s.id })]);
  } else {
    await run(db, "UPDATE submissions SET status='rejected', reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?", [req.user.id, s.id]);
  }
  db.close();
  res.json({ ok: true });
});

export default router;
