import { Router } from 'express';
import { getDb, get, all, run } from '../lib/db.js';
import { authRequired } from '../middleware/auth.js';

const router = Router();

router.get('/', async (req, res) => {
  const db = getDb();
  const rows = await all(db, 'SELECT * FROM tasks WHERE active=1 ORDER BY id DESC LIMIT 500', []);
  db.close();
  res.json(rows);
});

router.post('/', authRequired, async (req, res) => {
  const { title, category, description, external_url, price_cents=5, slots_total=10 } = req.body || {};
  if (!title || !category || !description) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  const db = getDb();
  try {
    const fee = Math.max(0, Math.floor(slots_total) * 1);
    await run(db, 'UPDATE users SET balance_cents=balance_cents-? WHERE id=?', [fee, req.user.id]);
    const result = await run(db, `INSERT INTO tasks(title, category, description, external_url, price_cents, slots_total, created_by) 
      VALUES (?,?,?,?,?,?,?)`, [title, category, description, external_url||'', price_cents, slots_total, req.user.id]);
    const taskId = result.lastID;
    await run(db, 'INSERT INTO txns(user_id, amount_cents, type, meta) VALUES (?,?,?,?)',
      [req.user.id, -fee, 'post_task_fee', JSON.stringify({ taskId, slots_total })]);
    const task = await get(db, 'SELECT * FROM tasks WHERE id=?', [taskId]);
    res.json(task);
  } finally {
    db.close();
  }
});

router.get('/:id', async (req, res) => {
  const db = getDb();
  const task = await get(db, 'SELECT * FROM tasks WHERE id=?', [req.params.id]);
  db.close();
  if (!task) return res.status(404).json({ error: 'Not found' });
  res.json(task);
});

router.post('/:id/submit', authRequired, async (req, res) => {
  const { proof_text, proof_url } = req.body || {};
  const db = getDb();
  const task = await get(db, 'SELECT * FROM tasks WHERE id=?', [req.params.id]);
  if (!task || !task.active) { db.close(); return res.status(400).json({ error: 'Task not available' }); }
  if (task.slots_taken >= task.slots_total) { db.close(); return res.status(400).json({ error: 'Slots filled' }); }
  const exists = await get(db, 'SELECT id FROM submissions WHERE task_id=? AND user_id=?', [task.id, req.user.id]);
  if (exists) { db.close(); return res.status(400).json({ error: 'Already submitted' }); }
  await run(db, 'INSERT INTO submissions(task_id,user_id,proof_text,proof_url) VALUES (?,?,?,?)',
    [task.id, req.user.id, proof_text||'', proof_url||'']);
  await run(db, 'UPDATE tasks SET slots_taken=slots_taken+1 WHERE id=?', [task.id]);
  db.close();
  res.json({ ok: true });
});

export default router;
